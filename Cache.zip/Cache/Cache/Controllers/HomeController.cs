﻿using Cache.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using System.Diagnostics;

namespace Cache.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IMemoryCache memoryCache;

        public HomeController(ILogger<HomeController> logger, IMemoryCache memoryCache)
        {
            _logger = logger;
            this.memoryCache = memoryCache;
        }

        public IActionResult Index()
        {
            var cacheKey = "Allcustomer";

            if (!memoryCache.TryGetValue(cacheKey, out List<Customer> customerList))
            {
                customerList = lst();
                var cacheExpiryOptions = new MemoryCacheEntryOptions
                {
                    AbsoluteExpiration = DateTime.Now.AddMinutes(5),
                    Priority = CacheItemPriority.High,
                    SlidingExpiration = TimeSpan.FromMinutes(2)
                };
                memoryCache.Set(cacheKey, customerList, cacheExpiryOptions);
            }

            return View();
        }

        public List<Customer> lst()
        {
            var list = new List<Customer>();

            Customer customer = new Customer();
            customer.Id = 1;
            customer.Name = "Anant";

            list.Add(customer);

            return list;
        } 
    }
}